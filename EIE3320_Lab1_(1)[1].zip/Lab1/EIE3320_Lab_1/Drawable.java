//ISLAM AHNAF AL 20041569D
//DINESH GAUTAM 20040968D
public interface Drawable {
    void draw();
}